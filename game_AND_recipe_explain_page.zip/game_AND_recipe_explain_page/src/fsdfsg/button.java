package fsdfsg;
import javax.swing.*;
import java.awt.*;

public class button {
    public static void main(String[] args) {
        // JFrame 생성
        JFrame frame = new JFrame("탭 패널 예제");

        // 탭 패널 생성
        JTabbedPane tabbedPane = new JTabbedPane();

        // 첫 번째 탭에 버튼 추가
        JPanel tab1 = new JPanel();
        JButton button1 = new JButton("버튼 1");
        tab1.add(button1);
        tabbedPane.addTab("탭 1", tab1);

        // 두 번째 탭에 버튼 추가
        JPanel tab2 = new JPanel();
        JButton button2 = new JButton("버튼 2");
        tab2.add(button2);
        tabbedPane.addTab("탭 2", tab2);

        // JFrame에 탭 패널 추가
        frame.add(tabbedPane);

        // JFrame 설정
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setVisible(true);
    }
}
